package com.example.administrator.myapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Log.d(TAG,"onCreate: started.");
        ImageView  first = (ImageView) findViewById(R.id.first);



        int imageResouce = getResources().getIdentifier("@drawable/tar1", null, this.getPackageName());
        first.setImageResource(imageResouce);


    }



}

