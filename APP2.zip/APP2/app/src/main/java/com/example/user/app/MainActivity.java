package com.example.user.app;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private Button saveBtn;
    private EditText edit_head,edit_description;
    private ListView lv_list;
    private ArrayList<Item> array;
    private ArrayAdapter<Item> adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        saveBtn = findViewById(R.id.saveBtn);
        edit_head = (EditText) findViewById(R.id.titleEditText);
        edit_description = (EditText)findViewById(R.id.descriptionEditText);
        lv_list = (ListView)findViewById(R.id.showDataLV);
        lv_list.setAdapter(adapter);

        array=new ArrayList<Item>();
        adapter=new Adapter(this,R.layout.custom_listview,array);

        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AddHead();
            }
        });

    }
    public void AddHead() {
        if (edit_head.getText().toString().equals("") || edit_description.getText().toString().equals(""))
            ;
        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle("Info Missing");
        builder.setMessage("Please add info..");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        builder.create().show();
    }  {
        final String head = edit_head.getText().toString();
        final String description = edit_head.getText().toString() + "h : " +edit_description.getText().toString() + "'";
        Item item=new Item(head,description);
        array.add(0,item);
        adapter.notifyDataSetChanged();
        edit_head.setText("");
        edit_description.setText("");
        edit_head.requestFocus();


    }
}




