package com.example.user.app;

public class Item {
    private String head;
    private String description;

    public Item(String head , String description){
        this.head = head;
        this.description = description;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
