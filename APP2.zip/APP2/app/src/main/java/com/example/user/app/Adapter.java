package com.example.user.app;

import android.app.Activity;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

public class Adapter extends ArrayAdapter<Item> {
    private Activity context;
    private int id;
    ArrayList<Item> array;



    public Adapter(@NonNull Activity context, int resource, @NonNull ArrayList<Item>objects) {
        super(context, resource, objects);
        this.context=context;
        this.id = resource;
        this.array=objects;

    }

    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        if (convertView==null){
            LayoutInflater inflater=context.getLayoutInflater();
            convertView=inflater.inflate(id,null);
        }
        final Item item = array.get(position);
        TextView texthead = convertView.findViewById(R.id.titleEditText);
        TextView textdescription = convertView.findViewById(R.id.descriptionEditText);


        texthead.setText(item.getHead());
        textdescription.setText(item.getDescription());


        return super.getView(position, convertView, parent);
    }

}
