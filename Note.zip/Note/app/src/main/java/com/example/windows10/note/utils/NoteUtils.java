package com.example.windows10.note.utils;

import android.icu.text.DateFormat;
import android.icu.text.SimpleDateFormat;
import android.os.Build;
import android.support.annotation.RequiresApi;

import java.util.Date;
import java.util.Locale;

public class NoteUtils {
    @RequiresApi(api = Build.VERSION_CODES.N)
    public static String dateFromLong (long time){
        DateFormat format = new SimpleDateFormat("EEE, dd MMM yyyy 'at' hh:mm aaa", Locale.US);
        return format.format(new Date(time));
    }
}
