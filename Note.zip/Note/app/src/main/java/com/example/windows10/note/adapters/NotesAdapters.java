package com.example.windows10.note.adapters;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.windows10.note.R;
import com.example.windows10.note.model.Note;
import com.example.windows10.note.utils.NoteUtils;

import java.util.ArrayList;

public class NotesAdapters extends  RecyclerView.Adapter<NotesAdapters.NoteHolder>{
    private ArrayList<Note> notes;

    public NotesAdapters(ArrayList<Note> notes) {
        this.notes = notes;
    }

    @NonNull
    @Override
    public NoteHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.note_layout, parent,false);
        return new NoteHolder(v);
    }

    @RequiresApi(api = Build.VERSION_CODES.N)
    @Override
    public void onBindViewHolder(@NonNull NoteHolder holder, int position) {
        Note note = getNote(position);
        if (note !=null ) {
            holder.noteText.setText(note.getNoteText());
            holder.noteDate.setText(NoteUtils.dateFromLong(note.getNoteDate()));
        }
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    private Note getNote (int position){
        return notes.get(position);
    }
    class NoteHolder extends RecyclerView.ViewHolder {
        TextView noteText,noteDate;
        public NoteHolder(@NonNull View itemView) {
            super(itemView);
        }
    }
}
